#!/usr/bin/env bash
set -euo pipefail
APP=/opt/worldcup-predictor
TARBALL="${1:-/tmp/phase_a21_deploy.tar.gz}"
FRONTEND_DIST=/var/www/worldcup/frontend/dist
STAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_ROOT=/opt/worldcup-backups

echo "=== Phase A21 Stability Deploy ==="
mkdir -p "${BACKUP_ROOT}"

if command -v pg_dump >/dev/null 2>&1 && [[ -n "${DATABASE_URL:-}" ]]; then
  pg_dump "${DATABASE_URL}" | gzip > "${BACKUP_ROOT}/pg_pre_a21_${STAMP}.sql.gz" || true
fi
if [[ -f "${APP}/data/football_intelligence.db" ]]; then
  cp -a "${APP}/data/football_intelligence.db" "${BACKUP_ROOT}/sqlite_pre_a21_${STAMP}.db"
fi
if [[ -d "${FRONTEND_DIST}" ]]; then
  tar czf "${BACKUP_ROOT}/frontend_dist_pre_a21_${STAMP}.tar.gz" -C "$(dirname "${FRONTEND_DIST}")" "$(basename "${FRONTEND_DIST}")"
fi
git -C "${APP}" rev-parse HEAD > "${BACKUP_ROOT}/commit_pre_a21_${STAMP}.txt" 2>/dev/null || true

if [[ -f "${TARBALL}" ]]; then
  tar xzf "${TARBALL}" -C "${APP}"
fi
cd "${APP}"
.venv/bin/python -c "from worldcup_predictor.database.repository import FootballIntelligenceRepository; from worldcup_predictor.database.migrations import ensure_schema_compat; ensure_schema_compat(FootballIntelligenceRepository()._conn)"
cd "${APP}/base44-d"
npm ci --silent 2>/dev/null || npm install --silent
npm run build
rsync -a --delete dist/ "${FRONTEND_DIST}/"
systemctl restart worldcup-api
sleep 5
systemctl is-active --quiet worldcup-api
nginx -t && systemctl reload nginx
SKIP_FRONTEND_BUILD=1 "${APP}/.venv/bin/python" "${APP}/scripts/validate_phase_a21_stability_bug_hunt.py"
bash "${APP}/scripts/deploy_phase_a21_smoke.sh"
echo "DEPLOY_OK"
