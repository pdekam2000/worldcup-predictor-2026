"""Phase 39B-1/39B-2/39B-3 — billing API (readiness + checkout + webhooks)."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from worldcup_predictor.api.deps import get_current_user, require_checkout_user
from worldcup_predictor.api.web_auth import WebAuthUser
from worldcup_predictor.billing.billing_service import BillingService, get_billing_service
from worldcup_predictor.billing.schemas import (
    CheckoutSessionRequest,
    CheckoutValidationError,
    CustomerPortalRequest,
    PlanPriceMappingError,
)
from worldcup_predictor.billing.webhook_service import WebhookService, WebhookVerificationError, get_webhook_service

router = APIRouter(prefix="/billing", tags=["billing"])


@router.get("/readiness")
def billing_readiness(
    _user: WebAuthUser = Depends(get_current_user),
    svc: BillingService = Depends(get_billing_service),
) -> dict[str, Any]:
    """Stripe billing readiness — yes/no only, no secrets or price IDs."""
    readiness = svc.readiness()
    return readiness.model_dump()


@router.post("/create-checkout-session")
def create_checkout_session(
    body: CheckoutSessionRequest,
    user: WebAuthUser = Depends(require_checkout_user),
    svc: BillingService = Depends(get_billing_service),
) -> dict[str, Any]:
    """Create Stripe Checkout session — does not activate plan (webhook authority in 39B-3)."""
    try:
        return svc.create_checkout_session(
            user_id=user.id,
            email=user.email or "",
            plan=body.plan,
        )
    except PlanPriceMappingError as exc:
        raise HTTPException(status_code=400, detail={"message": str(exc), "code": exc.code}) from exc
    except CheckoutValidationError as exc:
        raise HTTPException(
            status_code=exc.status_code,
            detail={"message": str(exc), "code": exc.code},
        ) from exc


@router.get("/status")
def billing_status(
    user: WebAuthUser = Depends(get_current_user),
    svc: BillingService = Depends(get_billing_service),
) -> dict[str, Any]:
    """Current user billing status — no secrets."""
    return svc.get_billing_status(user.id)


@router.get("/history")
def billing_history(
    user: WebAuthUser = Depends(get_current_user),
    svc: BillingService = Depends(get_billing_service),
    limit: int = 50,
    offset: int = 0,
) -> dict[str, Any]:
    """Invoice history for current user."""
    return svc.get_billing_history(user.id, limit=limit, offset=offset)


@router.post("/customer-portal")
def customer_portal(
    body: CustomerPortalRequest | None = None,
    user: WebAuthUser = Depends(require_checkout_user),
    svc: BillingService = Depends(get_billing_service),
) -> dict[str, Any]:
    """Stripe Customer Portal — manage subscription and payment method."""
    try:
        return svc.create_customer_portal_session(
            user.id,
            return_url=body.return_url if body else None,
        )
    except CheckoutValidationError as exc:
        raise HTTPException(
            status_code=exc.status_code,
            detail={"message": str(exc), "code": exc.code},
        ) from exc


@router.post("/webhook")
async def stripe_webhook(
    request: Request,
    svc: WebhookService = Depends(get_webhook_service),
) -> dict[str, Any]:
    """Stripe webhook — no JWT; signature verified via STRIPE_WEBHOOK_SECRET."""
    body = await request.body()
    signature = request.headers.get("Stripe-Signature")
    try:
        return svc.process_webhook(body, signature)
    except WebhookVerificationError as exc:
        raise HTTPException(
            status_code=400,
            detail={"message": str(exc), "code": exc.code},
        ) from exc
