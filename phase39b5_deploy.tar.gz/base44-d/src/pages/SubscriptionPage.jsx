import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  Check, Crown, Zap, User, CreditCard, Calendar, ArrowUpRight,
  AlertTriangle, MessageSquare, AlertCircle, Loader2, ExternalLink,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { contactAdmin, fetchSubscription, fetchUserQuota, fetchBillingStatus, fetchBillingHistory, createCustomerPortalSession, fetchBillingReadiness } from "@/api/saasApi";
import { PRICING_PLANS, CONTACT_CATEGORIES } from "@/lib/pricingPlans";
import UpgradeComingSoonDialog from "@/components/subscription/UpgradeComingSoonDialog";

const ICONS = { free: User, starter: Zap, pro: Crown };
const planLabels = { free: "Free", starter: "Starter", pro: "Pro", elite: "Pro", unlimited: "Pro" };

function formatDate(iso) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" });
  } catch {
    return "—";
  }
}

function QuotaWarningBanner({ warning, percent, remaining }) {
  if (!warning) return null;
  const config = {
    warning: {
      icon: AlertTriangle,
      className: "border-yellow-500/40 bg-yellow-500/10 text-yellow-200",
      title: "75% of monthly quota used",
      text: `${percent}% used · ${remaining} predictions remaining`,
    },
    critical: {
      icon: AlertCircle,
      className: "border-orange-500/40 bg-orange-500/10 text-orange-200",
      title: "90% of monthly quota used",
      text: `${percent}% used · ${remaining} remaining — consider upgrading`,
    },
    exhausted: {
      icon: AlertCircle,
      className: "border-red-500/40 bg-red-500/10 text-red-200",
      title: "Monthly quota exhausted",
      text: "Upgrade your plan or wait until the next billing cycle reset.",
    },
  };
  const c = config[warning] || config.warning;
  const Icon = c.icon;
  return (
    <div className={`rounded-xl p-4 border flex gap-3 items-start ${c.className}`}>
      <Icon className="w-5 h-5 flex-shrink-0 mt-0.5" />
      <div>
        <p className="font-semibold text-sm">{c.title}</p>
        <p className="text-xs opacity-90 mt-0.5">{c.text}</p>
      </div>
    </div>
  );
}

export default function SubscriptionPage() {
  const { toast } = useToast();
  const contactRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [subscription, setSubscription] = useState(null);
  const [billingHistory, setBillingHistory] = useState([]);
  const [quota, setQuota] = useState(null);
  const [contactSubject, setContactSubject] = useState("");
  const [contactMessage, setContactMessage] = useState("");
  const [contactCategory, setContactCategory] = useState("subscription");
  const [contactSending, setContactSending] = useState(false);
  const [upgradeOpen, setUpgradeOpen] = useState(false);
  const [upgradePlanName, setUpgradePlanName] = useState("");
  const [billingStatus, setBillingStatus] = useState(null);
  const [portalLoading, setPortalLoading] = useState(false);
  const [readiness, setReadiness] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [data, quotaData, statusData, historyData, readinessData] = await Promise.all([
        fetchSubscription(),
        fetchUserQuota().catch(() => null),
        fetchBillingStatus().catch(() => null),
        fetchBillingHistory().catch(() => ({ invoices: [] })),
        fetchBillingReadiness().catch(() => null),
      ]);
      setSubscription(data.subscription);
      setBillingHistory(historyData?.invoices?.length ? historyData.invoices.map((inv) => ({
        date: inv.date ? new Date(inv.date).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" }) : "—",
        desc: `${(inv.currency || "EUR").toUpperCase()} subscription`,
        amount: inv.amount_paid != null ? `€${Number(inv.amount_paid).toFixed(2)}` : "—",
        status: inv.status || "—",
        hosted_invoice_url: inv.hosted_invoice_url || "",
      })) : (data.billing_history || []));
      setQuota(quotaData);
      setBillingStatus(statusData);
      setReadiness(readinessData);
    } catch (err) {
      toast({
        title: "Could not load subscription",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    load();
  }, [load]);

  const rawPlan = subscription?.plan || "free";
  const currentPlan = rawPlan === "elite" || rawPlan === "unlimited" ? "pro" : rawPlan;
  const planLabel = planLabels[rawPlan] || "Free";
  const priceEur = quota?.price_eur ?? (currentPlan === "starter" ? 5 : currentPlan === "pro" ? 19 : 0);
  const limit = quota?.monthly_limit ?? quota?.daily_limit ?? 0;
  const used = quota?.used_this_period ?? quota?.used_today ?? 0;
  const remaining = quota?.remaining ?? 0;
  const percent = quota?.percent_used ?? (limit > 0 ? Math.round((used / limit) * 100) : 0);

  const openUpgrade = (planName) => {
    setUpgradePlanName(planName || "Starter");
    setUpgradeOpen(true);
  };

  const scrollToContact = () => {
    setUpgradeOpen(false);
    setContactCategory("subscription");
    contactRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleManageSubscription = async () => {
    setPortalLoading(true);
    try {
      const result = await createCustomerPortalSession(window.location.origin + "/subscription");
      const url = result?.portal_url;
      if (!url) throw new Error("Portal URL missing");
      window.location.href = url;
    } catch (err) {
      toast({
        title: "Could not open billing portal",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setPortalLoading(false);
    }
  };

  const checkoutPending = billingStatus?.checkout_pending === true;
  const cancelAtPeriodEnd = billingStatus?.cancel_at_period_end === true;
  const portalEnabled = billingStatus?.portal_enabled === true || readiness?.portal_enabled === true;
  const renewalDate = billingStatus?.current_period_end || quota?.period_end || quota?.next_reset_date;
  const billingStatusLabel = billingStatus?.billing_status || subscription?.status || "active";
  const lastPaymentStatus = billingStatus?.last_payment_status;

  const onContactAdmin = async (e) => {
    e.preventDefault();
    if (!contactSubject.trim() || !contactMessage.trim()) return;
    setContactSending(true);
    try {
      const res = await contactAdmin({
        subject: contactSubject.trim(),
        message: contactMessage.trim(),
        category: contactCategory,
      });
      setContactSubject("");
      setContactMessage("");
      toast({ title: res.message || "Message sent successfully" });
    } catch (err) {
      toast({
        title: "Could not send message",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setContactSending(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl font-display font-bold">Subscription</h1>
        <p className="text-sm text-muted-foreground mt-1">Your plan, usage, and billing cycle.</p>
      </div>

      {quota && !quota.bypass && (
        <QuotaWarningBanner warning={quota.quota_warning} percent={percent} remaining={remaining} />
      )}

      {checkoutPending && (
        <div className="rounded-xl p-4 border border-primary/40 bg-primary/10 flex gap-3 items-start text-primary">
          <Loader2 className="w-5 h-5 animate-spin flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-sm">Payment processing</p>
            <p className="text-xs opacity-90 mt-0.5">Waiting for Stripe confirmation. Your plan will update automatically.</p>
          </div>
        </div>
      )}

      {cancelAtPeriodEnd && currentPlan !== "free" && (
        <div className="rounded-xl p-4 border border-yellow-500/40 bg-yellow-500/10 flex gap-3 items-start text-yellow-200">
          <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-sm">Cancellation scheduled</p>
            <p className="text-xs opacity-90 mt-0.5">
              Your subscription ends on {formatDate(renewalDate)}. You keep access until then.
            </p>
          </div>
        </div>
      )}

      <div className="glass rounded-xl p-6 glow-blue">
        <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6">
          <div className="flex items-start gap-4 flex-1">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
              <Crown className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-display font-bold text-lg">{planLabel} Plan</div>
              <div className="text-sm text-muted-foreground">
                {currentPlan === "free" ? "€0/month" : `€${priceEur}/month`}
              </div>
              <div className="text-xs text-muted-foreground mt-2 space-y-1">
                <div>Billing cycle start: {formatDate(quota?.period_start)}</div>
                <div>Renewal / next reset: {formatDate(renewalDate)}</div>
                <div className="capitalize">Subscription: {billingStatus?.subscription_status || subscription?.status || "active"}</div>
                {billingStatusLabel && (
                  <div className="capitalize">Billing status: {billingStatusLabel.replace(/_/g, " ")}</div>
                )}
                {lastPaymentStatus && (
                  <div className="capitalize">Last payment: {lastPaymentStatus.replace(/_/g, " ")}</div>
                )}
              </div>
            </div>
          </div>

          {quota && !quota.bypass && (
            <div className="w-full lg:w-64 space-y-3">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Predictions used</span>
                <span className="font-medium text-foreground">{used} / {limit}</span>
              </div>
              <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${
                    percent >= 90 ? "bg-red-500" : percent >= 75 ? "bg-yellow-500" : "bg-primary"
                  }`}
                  style={{ width: `${Math.min(100, percent)}%` }}
                />
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">{percent}% used</span>
                <span className="text-muted-foreground">{remaining} remaining</span>
              </div>
            </div>
          )}

          {quota?.bypass && (
            <div className="text-xs text-muted-foreground">Admin bypass — unlimited</div>
          )}

          <div className="flex gap-3 flex-shrink-0 flex-wrap">
            {portalEnabled && currentPlan !== "free" && (
              <Button
                size="sm"
                variant="outline"
                className="rounded-lg"
                disabled={portalLoading}
                onClick={handleManageSubscription}
              >
                {portalLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Manage subscription"}
              </Button>
            )}
            {currentPlan !== "pro" && (
              <Button
                size="sm"
                className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-lg glow-gold"
                onClick={() => openUpgrade(currentPlan === "free" ? "Starter" : "Pro")}
              >
                Upgrade <ArrowUpRight className="w-4 h-4 ml-1" />
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="glass rounded-xl p-4 border border-yellow-500/30 flex gap-3 items-start">
        <AlertTriangle className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground leading-relaxed">
          <span className="text-yellow-400 font-semibold">Entertainment purposes only.</span> For informational and entertainment use only.
        </p>
      </div>

      <div>
        <h2 className="font-display font-semibold mb-4">Available Plans</h2>
        <div className="grid sm:grid-cols-3 gap-4">
          {PRICING_PLANS.map((plan) => {
            const Icon = ICONS[plan.key] || User;
            return (
              <div
                key={plan.key}
                className={`glass rounded-xl p-5 border ${
                  plan.recommended ? "border-primary/50 glow-blue" : "border-white/10"
                } relative`}
              >
                {plan.key === currentPlan && (
                  <div className="absolute -top-2.5 right-4 px-3 py-0.5 bg-primary text-primary-foreground text-xs font-semibold rounded-full">
                    Current
                  </div>
                )}
                {plan.recommended && plan.key !== currentPlan && (
                  <div className="absolute -top-2.5 left-4 px-3 py-0.5 bg-accent/20 text-accent text-xs font-semibold rounded-full">
                    Recommended
                  </div>
                )}
                <div className="flex items-center gap-2 mb-3">
                  <Icon className={`w-5 h-5 ${plan.recommended ? "text-primary" : "text-muted-foreground"}`} />
                  <h3 className="font-display font-bold">{plan.name}</h3>
                </div>
                <div className="mb-2">
                  <span className="text-3xl font-display font-bold">€{plan.price}</span>
                  {plan.price > 0 && <span className="text-muted-foreground text-sm">/mo</span>}
                </div>
                <p className="text-xs text-muted-foreground mb-3">{plan.monthlyPredictions}/month · {plan.markets.join(", ")}</p>
                <ul className="space-y-1.5 mb-4">
                  {plan.features.slice(0, 4).map((f) => (
                    <li key={f} className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Check className="w-3.5 h-3.5 text-primary flex-shrink-0" /> {f}
                    </li>
                  ))}
                </ul>
                <Button
                  size="sm"
                  className="w-full rounded-lg"
                  variant={plan.key === currentPlan ? "outline" : "default"}
                  disabled={plan.key === currentPlan}
                  onClick={() => openUpgrade(plan.name)}
                >
                  {plan.key === currentPlan ? "Current Plan" : `Upgrade to ${plan.name}`}
                </Button>
              </div>
            );
          })}
        </div>
      </div>

      <div ref={contactRef} className="glass rounded-xl p-5">
        <h2 className="font-display font-semibold mb-4 flex items-center gap-2">
          <MessageSquare className="w-4 h-4" /> Message Admin
        </h2>
        <form onSubmit={onContactAdmin} className="space-y-3 max-w-lg">
          <Select value={contactCategory} onValueChange={setContactCategory}>
            <SelectTrigger className="bg-white/5 border-white/10 rounded-lg">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent className="bg-card border-white/10">
              {CONTACT_CATEGORIES.map((c) => (
                <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            placeholder="Subject"
            value={contactSubject}
            onChange={(e) => setContactSubject(e.target.value)}
            className="bg-white/5 border-white/10 rounded-lg"
            maxLength={200}
            required
          />
          <Textarea
            placeholder="Your message…"
            value={contactMessage}
            onChange={(e) => setContactMessage(e.target.value)}
            className="bg-white/5 border-white/10 rounded-lg min-h-[100px]"
            maxLength={4000}
            required
          />
          <Button type="submit" disabled={contactSending} className="rounded-lg">
            {contactSending ? "Sending…" : "Send Message"}
          </Button>
        </form>
      </div>

      <div className="glass rounded-xl p-5">
        <h2 className="font-display font-semibold mb-4 flex items-center gap-2">
          <CreditCard className="w-4 h-4" /> Billing History
        </h2>
        {billingHistory.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground">
            <Calendar className="w-8 h-8 mx-auto mb-2 opacity-40" />
            No billing history yet. Payments will appear here after online billing is enabled.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-muted-foreground text-xs">
                  <th className="pb-3 font-medium">Date</th>
                  <th className="pb-3 font-medium">Description</th>
                  <th className="pb-3 font-medium">Amount</th>
                  <th className="pb-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {billingHistory.map((b, i) => (
                  <tr key={i}>
                    <td className="py-3 text-muted-foreground">{b.date}</td>
                    <td className="py-3 font-medium">{b.desc}</td>
                    <td className="py-3">{b.amount}</td>
                    <td className="py-3">
                      <span className="px-2 py-1 rounded-md text-xs font-medium bg-green-500/10 text-green-400">{b.status}</span>
                      {b.hosted_invoice_url && (
                        <a href={b.hosted_invoice_url} target="_blank" rel="noopener noreferrer" className="ml-2 inline-flex text-primary">
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <UpgradeComingSoonDialog
        open={upgradeOpen}
        onOpenChange={setUpgradeOpen}
        planName={upgradePlanName}
        onContactAdmin={scrollToContact}
      />
    </div>
  );
}
