import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2, MessageSquare } from "lucide-react";
import { createCheckoutSession, fetchBillingReadiness } from "@/api/saasApi";
import { useToast } from "@/components/ui/use-toast";

const PLAN_KEY = {
  Starter: "starter",
  starter: "starter",
  Pro: "pro",
  pro: "pro",
};

/**
 * Phase 39B-2 — upgrade dialog with Stripe checkout when enabled.
 */
export default function UpgradeComingSoonDialog({
  open,
  onOpenChange,
  planName,
  onContactAdmin,
}) {
  const { toast } = useToast();
  const [readiness, setReadiness] = useState(null);
  const [loadingReadiness, setLoadingReadiness] = useState(false);
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [error, setError] = useState("");

  const planKey = PLAN_KEY[planName] || PLAN_KEY.Starter;
  const checkoutEnabled = readiness?.checkout_enabled === true;

  useEffect(() => {
    if (!open) return;
    setError("");
    setLoadingReadiness(true);
    fetchBillingReadiness()
      .then(setReadiness)
      .catch(() => setReadiness({ checkout_enabled: false }))
      .finally(() => setLoadingReadiness(false));
  }, [open]);

  const handleCheckout = async () => {
    setError("");
    setCheckoutLoading(true);
    try {
      const result = await createCheckoutSession(planKey);
      const url = result?.checkout_url;
      if (!url) {
        throw new Error("Checkout URL missing");
      }
      window.location.href = url;
    } catch (err) {
      const message = err instanceof Error ? err.message : "Checkout failed";
      setError(message);
      toast({
        title: "Checkout unavailable",
        description: message,
        variant: "destructive",
      });
    } finally {
      setCheckoutLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass border-white/10 sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">
            {planName ? `Upgrade to ${planName}` : "Upgrade plan"}
          </DialogTitle>
          <DialogDescription className="text-muted-foreground pt-2 space-y-2">
            {loadingReadiness ? (
              <p>Checking payment availability…</p>
            ) : checkoutEnabled ? (
              <>
                <p>Continue to secure Stripe checkout for {planName || "your plan"}.</p>
                <p className="text-xs">Your plan activates after payment is confirmed — not on this screen.</p>
              </>
            ) : (
              <>
                <p>Payment system coming soon.</p>
                <p>Contact Admin if you want early access.</p>
              </>
            )}
            {error && <p className="text-destructive text-sm">{error}</p>}
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="rounded-lg">
            Close
          </Button>
          {checkoutEnabled ? (
            <Button
              onClick={handleCheckout}
              disabled={checkoutLoading || loadingReadiness}
              className="rounded-lg gap-2"
            >
              {checkoutLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                `Checkout ${planName || "plan"}`
              )}
            </Button>
          ) : onContactAdmin ? (
            <Button onClick={onContactAdmin} className="rounded-lg gap-2">
              <MessageSquare className="w-4 h-4" /> Message Admin
            </Button>
          ) : (
            <Button asChild className="rounded-lg gap-2">
              <Link to="/subscription">
                <MessageSquare className="w-4 h-4" /> Message Admin
              </Link>
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
