"""Daily prediction usage tracking — SQLite (works with or without PostgreSQL)."""

from __future__ import annotations

from datetime import datetime, timezone

from worldcup_predictor.config.settings import Settings, get_settings
from worldcup_predictor.database.repository import FootballIntelligenceRepository

_USAGE_DDL = """
CREATE TABLE IF NOT EXISTS user_daily_prediction_usage (
    user_id TEXT NOT NULL,
    usage_date TEXT NOT NULL,
    fixture_id INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (user_id, usage_date, fixture_id)
)
"""


def _utc_today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(tzinfo=None).isoformat()


class PredictionUsageStore:
    def __init__(self, settings: Settings | None = None) -> None:
        self._settings = settings or get_settings()
        self._repo = FootballIntelligenceRepository(self._settings.sqlite_path or None)
        self._repo._conn.execute(_USAGE_DDL)
        self._repo._conn.commit()

    def count_today(self, user_id: str) -> int:
        row = self._repo._conn.execute(
            """
            SELECT COUNT(*) AS c FROM user_daily_prediction_usage
            WHERE user_id = ? AND usage_date = ?
            """,
            (str(user_id), _utc_today()),
        ).fetchone()
        return int(row["c"]) if row else 0

    def has_fixture_today(self, user_id: str, fixture_id: int) -> bool:
        row = self._repo._conn.execute(
            """
            SELECT 1 FROM user_daily_prediction_usage
            WHERE user_id = ? AND usage_date = ? AND fixture_id = ?
            """,
            (str(user_id), _utc_today(), int(fixture_id)),
        ).fetchone()
        return row is not None

    def record(self, user_id: str, fixture_id: int) -> None:
        self._repo._conn.execute(
            """
            INSERT OR IGNORE INTO user_daily_prediction_usage
                (user_id, usage_date, fixture_id, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (str(user_id), _utc_today(), int(fixture_id), _utc_now()),
        )
        self._repo._conn.commit()
