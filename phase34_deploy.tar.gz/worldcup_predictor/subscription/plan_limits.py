"""Plan tier daily prediction limits — Phase 34."""

from __future__ import annotations

from worldcup_predictor.database.postgres.enums import SubscriptionPlan

# None = unlimited pipeline runs per day
PLAN_DAILY_PREDICTION_LIMITS: dict[SubscriptionPlan, int | None] = {
    SubscriptionPlan.FREE: 1,
    SubscriptionPlan.PRO: None,
    SubscriptionPlan.ELITE: None,
    SubscriptionPlan.UNLIMITED: None,
}

PLAN_FEATURES: dict[str, dict[str, object]] = {
    "free": {
        "daily_predictions": 1,
        "full_history": False,
        "ranked_picks": False,
        "advanced_markets": False,
    },
    "pro": {
        "daily_predictions": None,
        "full_history": True,
        "ranked_picks": True,
        "advanced_markets": True,
    },
    "elite": {
        "daily_predictions": None,
        "full_history": True,
        "ranked_picks": True,
        "advanced_markets": True,
    },
    "unlimited": {
        "daily_predictions": None,
        "full_history": True,
        "ranked_picks": True,
        "advanced_markets": True,
    },
}
