"""User subscription quota enforcement — Phase 34."""

from __future__ import annotations

import uuid
from dataclasses import dataclass

from worldcup_predictor.database.postgres.enums import SubscriptionPlan
from worldcup_predictor.database.saas_factory import saas_uow
from worldcup_predictor.subscription.plan_limits import PLAN_DAILY_PREDICTION_LIMITS
from worldcup_predictor.subscription.usage_store import PredictionUsageStore


class SubscriptionQuotaError(Exception):
    def __init__(self, message: str, *, code: str = "quota_exceeded", limit: int | None = None, used: int = 0) -> None:
        super().__init__(message)
        self.code = code
        self.limit = limit
        self.used = used


@dataclass(frozen=True)
class QuotaCheckResult:
    allowed: bool
    plan: str
    daily_limit: int | None
    used_today: int
    remaining: int | None
    bypass: bool = False
    message: str | None = None


def _resolve_plan(user_id: str) -> SubscriptionPlan:
    try:
        uid = uuid.UUID(str(user_id))
        with saas_uow() as uow:
            sub = uow.subscriptions.get_for_user(uid)
            return sub.plan if sub else SubscriptionPlan.FREE
    except Exception:
        return SubscriptionPlan.FREE


def get_user_quota_status(
    user_id: str,
    *,
    role: str = "user",
    fixture_id: int | None = None,
) -> QuotaCheckResult:
    if role == "admin":
        return QuotaCheckResult(
            allowed=True,
            plan="admin",
            daily_limit=None,
            used_today=0,
            remaining=None,
            bypass=True,
        )

    plan = _resolve_plan(user_id)
    limit = PLAN_DAILY_PREDICTION_LIMITS.get(plan, 1)
    store = PredictionUsageStore()
    used = store.count_today(user_id)

    if limit is None:
        return QuotaCheckResult(
            allowed=True,
            plan=plan.value,
            daily_limit=None,
            used_today=used,
            remaining=None,
        )

    if fixture_id is not None and store.has_fixture_today(user_id, fixture_id):
        return QuotaCheckResult(
            allowed=True,
            plan=plan.value,
            daily_limit=limit,
            used_today=used,
            remaining=max(0, limit - used),
            message="Already counted for this fixture today",
        )

    remaining = max(0, limit - used)
    allowed = used < limit
    return QuotaCheckResult(
        allowed=allowed,
        plan=plan.value,
        daily_limit=limit,
        used_today=used,
        remaining=remaining,
        message=None if allowed else "Daily prediction limit reached. Upgrade to PRO for unlimited predictions.",
    )


def assert_prediction_allowed(
    user_id: str,
    *,
    role: str = "user",
    fixture_id: int | None = None,
) -> QuotaCheckResult:
    result = get_user_quota_status(user_id, role=role, fixture_id=fixture_id)
    if not result.allowed:
        raise SubscriptionQuotaError(
            result.message or "Daily prediction limit reached.",
            limit=result.daily_limit,
            used=result.used_today,
        )
    return result


def record_prediction_usage(user_id: str, fixture_id: int) -> None:
    PredictionUsageStore().record(user_id, fixture_id)
