"""Phase 42C — build prediction archive detail payloads from stored history + snapshots."""

from __future__ import annotations

import json
import uuid
from typing import Any, Literal

from worldcup_predictor.api.prediction_history_evaluation import (
    FixtureOutcome,
    FixtureOutcomeResolver,
    evaluate_history_record,
)
from worldcup_predictor.automation.worldcup_background.pick_evaluator import evaluate_stored_prediction
from worldcup_predictor.config.competitions import DEFAULT_COMPETITION_KEY, get_competition
from worldcup_predictor.config.settings import Settings, get_settings
from worldcup_predictor.database.postgres.schemas import PredictionHistoryRecord
from worldcup_predictor.quota.prediction_cache import kickoff_from_payload
from worldcup_predictor.results.match_results_store import MatchResultsStore

SnapshotSource = Literal["sqlite", "cache", "history_only"]

_SELECTION_LABELS: dict[str, str] = {
    "home": "Home Win",
    "home_win": "Home Win",
    "draw": "Draw",
    "away": "Away Win",
    "away_win": "Away Win",
    "over_2_5": "Over 2.5",
    "under_2_5": "Under 2.5",
    "yes": "BTTS Yes",
    "no": "BTTS No",
    "btts_yes": "BTTS Yes",
    "btts_no": "BTTS No",
}

_MARKET_EVAL_KEYS: dict[str, str] = {
    "1x2": "1x2",
    "over_under_2_5": "over_under_2_5",
    "btts": "btts",
    "double_chance": "double_chance",
}


def _display_selection(value: Any) -> str:
    if value is None:
        return "—"
    key = str(value).lower()
    return _SELECTION_LABELS.get(key, str(value).replace("_", " ").title())


def _prob_pct(value: Any) -> float | None:
    if value is None:
        return None
    try:
        num = float(value)
    except (TypeError, ValueError):
        return None
    if 0 <= num <= 1:
        return round(num * 100, 1)
    return round(num, 1)


def _raw_file_cache(
    fixture_id: int,
    *,
    competition_key: str,
    season: int,
    locale: str,
    settings: Settings,
) -> dict[str, Any] | None:
    try:
        from worldcup_predictor.quota.prediction_cache import _cache, _cache_params

        payload = _cache(settings).get(
            "prediction_result",
            _cache_params(fixture_id, competition_key=competition_key, season=season, locale=locale),
        )
        return dict(payload) if isinstance(payload, dict) else None
    except Exception:
        return None


def load_archive_snapshot(
    fixture_id: int,
    *,
    settings: Settings | None = None,
) -> tuple[dict[str, Any] | None, SnapshotSource]:
    """Load the best available stored prediction snapshot — no engine re-run."""
    settings = settings or get_settings()
    comp = get_competition(DEFAULT_COMPETITION_KEY)

    try:
        from worldcup_predictor.database.repository import FootballIntelligenceRepository

        repo = FootballIntelligenceRepository(settings.sqlite_path or None)
        row = repo.get_worldcup_stored_prediction(fixture_id, include_inactive=True)
        if row and row.get("payload_json"):
            payload = json.loads(row["payload_json"])
            if isinstance(payload, dict):
                return payload, "sqlite"
    except Exception:
        pass

    cached = _raw_file_cache(
        fixture_id,
        competition_key=comp.key,
        season=comp.season,
        locale="en",
        settings=settings,
    )
    if cached:
        return cached, "cache"

    return None, "history_only"


def _market_block(
    *,
    key: str,
    label: str,
    selection: Any = None,
    probabilities: dict[str, Any] | None = None,
    confidence: float | None = None,
    result_status: str | None = None,
    withheld: bool = False,
    withheld_reason: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    block: dict[str, Any] = {
        "key": key,
        "label": label,
        "selection": selection,
        "display_selection": _display_selection(selection),
        "probabilities": probabilities or {},
        "confidence": confidence,
        "result_status": result_status,
        "withheld": withheld,
    }
    if withheld_reason:
        block["withheld_reason"] = withheld_reason
    if extra:
        block.update(extra)
    return block


def _consistency_status(raw: dict[str, Any] | None) -> tuple[bool, str | None]:
    if not isinstance(raw, dict):
        return False, None
    status = str(raw.get("consistency_status") or "").lower()
    if status == "withheld" or raw.get("display_allowed") is False:
        return True, raw.get("withheld_reason")
    return False, None


def _build_markets(
    snapshot: dict[str, Any] | None,
    *,
    record: PredictionHistoryRecord,
    market_eval: dict[str, str] | None,
    outcome: FixtureOutcome,
) -> list[dict[str, Any]]:
    markets: list[dict[str, Any]] = []
    dm = (snapshot or {}).get("detailed_markets") or {}
    if not isinstance(dm, dict):
        dm = {}

    pending = not outcome.is_finished
    default_status = "pending" if pending else None

    mw = dm.get("match_winner") if isinstance(dm.get("match_winner"), dict) else {}
    mw_sel = mw.get("selection") or (snapshot or {}).get("prediction")
    if not mw_sel and record.prediction_1x2:
        mw_sel = record.prediction_1x2.value
    mw_probs = mw.get("probabilities") if isinstance(mw.get("probabilities"), dict) else {}
    markets.append(
        _market_block(
            key="1x2",
            label="Match Result (1X2)",
            selection=mw_sel,
            probabilities=mw_probs,
            confidence=_prob_pct(mw.get("probability")),
            result_status=(market_eval or {}).get("1x2") or default_status,
        )
    )

    btts = dm.get("btts") if isinstance(dm.get("btts"), dict) else {}
    btts_withheld, btts_reason = _consistency_status(btts)
    markets.append(
        _market_block(
            key="btts",
            label="Both Teams To Score",
            selection=btts.get("selection"),
            probabilities=btts.get("probabilities") if isinstance(btts.get("probabilities"), dict) else {},
            confidence=_prob_pct(btts.get("probability")),
            result_status=(market_eval or {}).get("btts") or default_status,
            withheld=btts_withheld,
            withheld_reason=btts_reason,
        )
    )

    ou = dm.get("over_under_25") if isinstance(dm.get("over_under_25"), dict) else {}
    ou_withheld, ou_reason = _consistency_status(ou)
    markets.append(
        _market_block(
            key="over_under_2_5",
            label="Over/Under 2.5",
            selection=ou.get("selection"),
            probabilities=ou.get("probabilities") if isinstance(ou.get("probabilities"), dict) else {},
            confidence=_prob_pct(ou.get("probability")),
            result_status=(market_eval or {}).get("over_under_2_5") or default_status,
            withheld=ou_withheld,
            withheld_reason=ou_reason,
        )
    )

    fg = dm.get("first_goal") if isinstance(dm.get("first_goal"), dict) else {}
    fg_withheld, fg_reason = _consistency_status(fg)
    markets.append(
        _market_block(
            key="first_team_to_score",
            label="First Team To Score",
            selection=fg.get("team"),
            probabilities={},
            confidence=_prob_pct(fg.get("confidence")),
            result_status=default_status,
            withheld=fg_withheld,
            withheld_reason=fg_reason,
            extra={"team": fg.get("team")},
        )
    )

    markets.append(
        _market_block(
            key="goal_timing",
            label="Goal Timing",
            selection=fg.get("minute_range") or fg.get("expected_minute"),
            probabilities={},
            confidence=_prob_pct(fg.get("confidence")),
            result_status=default_status,
            withheld=fg_withheld,
            withheld_reason=fg_reason,
            extra={
                "minute_range": fg.get("minute_range"),
                "expected_minute": fg.get("expected_minute"),
            },
        )
    )

    gs = dm.get("goalscorer") if isinstance(dm.get("goalscorer"), dict) else {}
    gs_withheld, gs_reason = _consistency_status(gs)
    if gs.get("available") is not False or gs.get("player"):
        markets.append(
            _market_block(
                key="goalscorer",
                label="Goalscorer",
                selection=gs.get("player"),
                probabilities={},
                confidence=_prob_pct(gs.get("confidence")),
                result_status=default_status,
                withheld=gs_withheld,
                withheld_reason=gs_reason,
                extra={"team": gs.get("team"), "available": bool(gs.get("available", True))},
            )
        )

    dc = dm.get("double_chance") if isinstance(dm.get("double_chance"), dict) else {}
    if dc:
        best_key = max(
            ("home_or_draw", "draw_or_away", "home_or_away"),
            key=lambda k: float(dc.get(k) or 0),
        )
        dc_withheld, dc_reason = _consistency_status(dc)
        markets.append(
            _market_block(
                key="double_chance",
                label="Double Chance",
                selection=best_key,
                probabilities={
                    "home_or_draw": dc.get("home_or_draw"),
                    "draw_or_away": dc.get("draw_or_away"),
                    "home_or_away": dc.get("home_or_away"),
                },
                confidence=float(dc.get(best_key) or 0) if dc.get(best_key) is not None else None,
                result_status=(market_eval or {}).get("double_chance") or default_status,
                withheld=dc_withheld,
                withheld_reason=dc_reason,
            )
        )

    if not snapshot and record.prediction_1x2 and len(markets) == 1:
        pass

    return markets


def _market_outcomes(fixture_id: int, outcome: FixtureOutcome) -> dict[str, Any]:
    results: dict[str, Any] = {}
    if outcome.final_score:
        results["final_score"] = outcome.final_score
    if outcome.actual_result:
        results["winner"] = outcome.actual_result

    jsonl = MatchResultsStore().by_fixture_id().get(fixture_id)
    if jsonl is not None:
        results["over_under_2_5"] = jsonl.over_under_2_5_result
        if jsonl.final_score and "-" in jsonl.final_score:
            parts = jsonl.final_score.split("-", 1)
            try:
                h, a = int(parts[0]), int(parts[1])
                results["btts"] = "yes" if h > 0 and a > 0 else "no"
                results["total_goals"] = h + a
            except ValueError:
                pass
        elif jsonl.total_goals is not None:
            results["total_goals"] = jsonl.total_goals
    elif outcome.is_finished and outcome.final_score and "-" in outcome.final_score:
        parts = outcome.final_score.split("-", 1)
        try:
            h, a = int(parts[0]), int(parts[1])
            total = h + a
            results["over_under_2_5"] = "over_2_5" if total > 2 else "under_2_5"
            results["btts"] = "yes" if h > 0 and a > 0 else "no"
            results["total_goals"] = total
        except ValueError:
            pass

    return results


def _consistency_section(snapshot: dict[str, Any] | None) -> dict[str, Any]:
    guard = (snapshot or {}).get("consistency_guard") or {}
    if not isinstance(guard, dict) or not guard:
        return {
            "available": False,
            "withheld_markets": [],
            "consistency_warnings": [],
        }
    return {
        "available": bool(guard.get("applied")),
        "withheld_markets": list(guard.get("withheld_markets") or []),
        "consistency_warnings": list(guard.get("consistency_warnings") or []),
        "rules_version": guard.get("rules_version"),
        "applied_rules": list(guard.get("applied_rules") or []),
    }


def _metadata_section(
    snapshot: dict[str, Any] | None,
    *,
    snapshot_source: SnapshotSource,
    record: PredictionHistoryRecord,
) -> dict[str, Any]:
    snap = snapshot or {}
    generated_at = snap.get("generated_at") or snap.get("predicted_at")
    if not generated_at and record.viewed_at:
        generated_at = record.viewed_at.isoformat()

    return {
        "prediction_engine_version": snap.get("prediction_engine_version"),
        "adaptive_confidence_version": snap.get("adaptive_confidence_version"),
        "generated_at": generated_at,
        "snapshot_source": snapshot_source,
        "cache_schema_version": snap.get("cache_schema_version"),
        "data_quality": snap.get("data_quality"),
        "kickoff_utc": snap.get("kickoff_utc") or (kickoff_from_payload(snap).isoformat() if kickoff_from_payload(snap) else None),
    }


def build_prediction_archive_detail(
    record: PredictionHistoryRecord,
    *,
    resolver: FixtureOutcomeResolver | None = None,
    settings: Settings | None = None,
) -> dict[str, Any]:
    """Merge evaluated history row with stored prediction snapshot for archive detail."""
    settings = settings or get_settings()
    resolver = resolver or FixtureOutcomeResolver(settings=settings)
    evaluated = evaluate_history_record(record, resolver=resolver, settings=settings)
    outcome = resolver.resolve(record.fixture_id)
    snapshot, snapshot_source = load_archive_snapshot(record.fixture_id, settings=settings)

    market_eval: dict[str, str] | None = None
    if snapshot:
        eval_payload = dict(snapshot)
        if not eval_payload.get("prediction") and record.prediction_1x2:
            eval_payload["prediction"] = record.prediction_1x2.value
        stored_eval = evaluate_stored_prediction(eval_payload, outcome)
        raw_markets = stored_eval.get("markets") or {}
        market_eval = {k: str(v) for k, v in raw_markets.items() if k in _MARKET_EVAL_KEYS.values() or k in _MARKET_EVAL_KEYS}

    match_name = f"{record.home_team} vs {record.away_team}"
    confidence = evaluated.get("confidence")
    main_prediction = evaluated.get("predicted_1x2")

    return {
        "status": "ok",
        "entry_id": str(record.id),
        "prediction_id": record.prediction_id,
        "fixture_id": record.fixture_id,
        "match_name": match_name,
        "competition": record.league or "World Cup 2026",
        "match_date": evaluated.get("match_date"),
        "prediction_date": evaluated.get("viewed_at"),
        "home_team": record.home_team,
        "away_team": record.away_team,
        "summary": {
            "confidence": confidence,
            "main_prediction": main_prediction,
            "main_prediction_label": _display_selection(main_prediction),
            "result_status": evaluated.get("result_status"),
        },
        "prediction": {
            "markets": _build_markets(
                snapshot,
                record=record,
                market_eval=market_eval,
                outcome=outcome,
            ),
            "probabilities": (snapshot or {}).get("probabilities") or {},
            "confidence": confidence,
            "detailed_markets_available": snapshot is not None,
        },
        "evaluation": {
            "result_status": evaluated.get("result_status"),
            "is_correct": evaluated.get("is_correct"),
            "actual_result": evaluated.get("actual_result"),
            "actual_result_label": _display_selection(evaluated.get("actual_result")),
            "final_score": evaluated.get("final_score"),
            "evaluated_at": evaluated.get("evaluated_at"),
            "is_finished": evaluated.get("is_finished"),
            "market_outcomes": _market_outcomes(record.fixture_id, outcome),
        },
        "consistency": _consistency_section(snapshot),
        "metadata": _metadata_section(snapshot, snapshot_source=snapshot_source, record=record),
        "premium_placeholders": {
            "specialist_votes": {"available": False, "message": "Premium feature — coming soon"},
            "agent_explanations": {"available": False, "message": "Premium feature — coming soon"},
            "odds_movement": {"available": False, "message": "Premium feature — coming soon"},
            "prediction_snapshots": {"available": False, "message": "Premium feature — coming soon"},
        },
    }


def fetch_archive_detail_for_user(
    user_id: uuid.UUID,
    entry_id: uuid.UUID,
    *,
    settings: Settings | None = None,
) -> dict[str, Any] | None:
    from worldcup_predictor.database.saas_factory import saas_uow

    with saas_uow() as uow:
        record = uow.prediction_history.get_for_user(user_id, entry_id)
    if record is None:
        return None
    return build_prediction_archive_detail(record, settings=settings)
