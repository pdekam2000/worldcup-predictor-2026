"""Phase 62 — World Cup EGIE data expansion configuration."""

from __future__ import annotations

from dataclasses import dataclass

WORLD_CUP_COMPETITION_KEY = "world_cup_2026"
API_FOOTBALL_LEAGUE_ID = 1
SPORTMONKS_LEAGUE_ID = 732

# Target historical seasons (API-Football season year)
WORLD_CUP_SEASONS: tuple[int, ...] = (2010, 2014, 2018, 2022, 2026)

# Coverage targets (Part F)
TARGET_FIXTURES = 500
TARGET_XG_COVERAGE = 0.70
TARGET_LINEUP_COVERAGE = 0.80
TARGET_ODDS_COVERAGE = 0.80
TARGET_GOAL_EVENT_COVERAGE = 0.90

RAW_CACHE_DIR = "data/egie/world_cup/raw"
SURVIVAL_OUTPUT = "data/egie/world_cup/survival_dataset.parquet"
TEAM_PROFILES_OUTPUT = "data/egie/world_cup/team_timing_profiles.json"
CONFEDERATION_PROFILES_OUTPUT = "data/egie/world_cup/confederation_timing_profiles.json"


@dataclass(frozen=True)
class WorldCupSeasonSpec:
    season: int
    label: str
    sportmonks_season_label: str | None = None


WORLD_CUP_SEASON_SPECS: tuple[WorldCupSeasonSpec, ...] = tuple(
    WorldCupSeasonSpec(s, f"FIFA World Cup {s}", str(s) if s >= 2018 else None)
    for s in WORLD_CUP_SEASONS
)
