import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Trophy,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Clock,
  ChevronDown,
  ChevronUp,
  BarChart3,
} from "lucide-react";
import { fetchEvaluatedResults } from "@/api/saasApi";
import { Button } from "@/components/ui/button";
import MatchTeamsRow from "@/components/match/MatchTeamsRow";
import { getArchiveStatusConfig, pick1x2Label } from "@/lib/archiveStatus";

const RANGE_TABS = [
  { id: "yesterday", label: "Yesterday" },
  { id: "7d", label: "Last 7 days" },
  { id: "30d", label: "Last 30 days" },
  { id: "all", label: "All evaluated" },
];

const STATUS_TABS = [
  { id: "all", label: "All" },
  { id: "evaluated", label: "Evaluated" },
  { id: "correct", label: "Correct" },
  { id: "wrong", label: "Wrong" },
  { id: "partial", label: "Partial" },
  { id: "pending", label: "Pending" },
];

const MARKET_LABELS = {
  "1x2": "1X2",
  btts: "BTTS",
  over_under_2_5: "O/U 2.5",
  double_chance: "Double Chance",
  correct_score: "Correct Score",
  first_goal_team: "First Goal Team",
  goal_minute: "Goal Minute",
  ht_result: "HT Result",
  goalscorer: "Goalscorer",
};

function formatKickoff(value) {
  if (!value) return "—";
  try {
    return new Date(value).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
  } catch {
    return "—";
  }
}

function marketColorClass(color) {
  if (color === "green") return "text-[#00E676] border-[#00E676]/30 bg-[#00E676]/10";
  if (color === "red") return "text-[#FF4D4D] border-[#FF4D4D]/30 bg-[#FF4D4D]/10";
  if (color === "purple") return "text-violet-300 border-violet-500/30 bg-violet-500/10";
  if (color === "yellow") return "text-[#FFD166] border-[#FFD166]/30 bg-[#FFD166]/10";
  return "text-[#94A3B8] border-white/10 bg-white/5";
}

function ResultCard({ item, index }) {
  const [open, setOpen] = useState(false);
  const statusKey = item.overall_status || item.result_status || "pending";
  const cfg = getArchiveStatusConfig(statusKey);
  const Icon = cfg.icon;
  const pred = item.predicted_pick || item.prediction_summary?.best_pick;
  const markets = item.market_statuses || {};
  const colors = item.market_colors || item.colors || {};

  return (
    <motion.article
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.03, 0.3) }}
      className={`rounded-xl border p-4 ${cfg.card}`}
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 flex-1 space-y-3">
          <div className="flex items-center gap-2 text-xs text-[#94A3B8]">
            <Trophy className="w-3.5 h-3.5" />
            <span>{item.competition || "Competition"}</span>
            <span>·</span>
            <span>{formatKickoff(item.kickoff || item.match_date)}</span>
          </div>
          <MatchTeamsRow
            homeTeam={item.home_team}
            awayTeam={item.away_team}
            size="md"
          />
          <div className="grid sm:grid-cols-3 gap-2 text-sm">
            <div className="rounded-lg bg-black/20 border border-white/[0.06] px-3 py-2">
              <div className="text-[10px] uppercase tracking-wide text-[#64748B]">Predicted</div>
              <div className="font-medium text-[#F8FAFC]">{pick1x2Label(pred) || pred || "—"}</div>
            </div>
            <div className="rounded-lg bg-black/20 border border-white/[0.06] px-3 py-2">
              <div className="text-[10px] uppercase tracking-wide text-[#64748B]">Final score</div>
              <div className="font-mono font-semibold text-[#F8FAFC]">{item.final_score || "—"}</div>
            </div>
            <div className="rounded-lg bg-black/20 border border-white/[0.06] px-3 py-2">
              <div className="text-[10px] uppercase tracking-wide text-[#64748B]">Outcome</div>
              <div className="text-[#94A3B8] capitalize">{(item.actual_result || "—").replace(/_/g, " ")}</div>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-start sm:items-end gap-2 shrink-0">
          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${cfg.badge}`}>
            <Icon className="w-3.5 h-3.5" />
            {cfg.label}
          </span>
          {item.is_quarantined && (
            <span className="text-[10px] px-2 py-0.5 rounded border border-amber-500/30 text-amber-300 bg-amber-500/10">
              Data quarantine
            </span>
          )}
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="outline" size="sm" className="border-white/10 h-8 text-xs">
              <Link to={item.detail_url || `/matches/${item.fixture_id}`}>Match detail</Link>
            </Button>
            {item.archive_entry_id && (
              <Button asChild variant="outline" size="sm" className="border-white/10 h-8 text-xs">
                <Link to={`/archive/${item.archive_entry_id}`}>Archive</Link>
              </Button>
            )}
          </div>
        </div>
      </div>

      {Object.keys(markets).length > 0 && (
        <div className="mt-4 border-t border-white/[0.06] pt-3">
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="flex items-center gap-2 text-xs text-[#94A3B8] hover:text-[#F8FAFC]"
          >
            {open ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            Market breakdown ({Object.keys(markets).length})
          </button>
          <AnimatePresence>
            {open && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="flex flex-wrap gap-2 mt-3">
                  {Object.entries(markets).map(([key, status]) => (
                    <span
                      key={key}
                      className={`text-[11px] px-2 py-1 rounded-full border capitalize ${marketColorClass(colors[key])}`}
                    >
                      {MARKET_LABELS[key] || key.replace(/_/g, " ")}: {status}
                    </span>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </motion.article>
  );
}

export default function PredictionResultsPage() {
  const [range, setRange] = useState("all");
  const [status, setStatus] = useState("all");
  const [results, setResults] = useState([]);
  const [counts, setCounts] = useState({ correct: 0, wrong: 0, partial: 0, pending: 0 });
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const apiStatus = status === "evaluated" ? "all" : status;
      const utcOffsetMinutes = -new Date().getTimezoneOffset();
      const data = await fetchEvaluatedResults({
        range,
        status: apiStatus,
        limit: 200,
        utcOffsetMinutes,
      });
      let rows = data.results || [];
      if (status === "evaluated") {
        rows = rows.filter((r) => ["correct", "wrong", "partial"].includes(r.overall_status));
      } else if (status !== "all") {
        rows = rows.filter((r) => r.overall_status === status);
      }
      setResults(rows);
      setCounts(data.counts || {});
      setTotalCount(data.total_count ?? rows.length);
    } catch (err) {
      setResults([]);
      setError(err instanceof Error ? err.message : "Failed to load results");
    } finally {
      setLoading(false);
    }
  }, [range, status]);

  useEffect(() => {
    load();
  }, [load]);

  const summaryCards = useMemo(
    () => [
      { label: "Total", value: totalCount, color: "text-[#F8FAFC]", icon: BarChart3 },
      { label: "Correct", value: counts.correct ?? 0, color: "text-[#00E676]", icon: CheckCircle2 },
      { label: "Wrong", value: counts.wrong ?? 0, color: "text-[#FF4D4D]", icon: XCircle },
      { label: "Partial", value: counts.partial ?? 0, color: "text-violet-400", icon: Clock },
      { label: "Pending", value: counts.pending ?? 0, color: "text-[#FFD166]", icon: Clock },
    ],
    [totalCount, counts]
  );

  return (
    <div className="space-y-6 max-w-5xl mx-auto px-1 sm:px-0 pb-12">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold flex items-center gap-2 text-[#F8FAFC]">
            <CheckCircle2 className="w-7 h-7 text-[#00E676]" />
            Prediction Results
          </h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Finished matches with stored predictions — actual scores and correct/wrong status from production evaluations.
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button asChild variant="outline" size="sm" className="border-white/10">
            <Link to="/archive">Archive</Link>
          </Button>
          <Button asChild variant="outline" size="sm" className="border-white/10">
            <Link to="/matches?status=finished">Match Center · Finished</Link>
          </Button>
          <Button variant="outline" size="sm" onClick={load} disabled={loading} className="border-white/10">
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-red-500/30 p-4 flex items-center gap-2 text-red-300 text-sm">
          <AlertCircle className="w-4 h-4" /> {error}
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {summaryCards.map((s) => (
          <div key={s.label} className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-4 text-center">
            <div className={`text-2xl font-bold tabular-nums ${s.color}`}>{loading ? "…" : s.value}</div>
            <div className="text-xs text-[#64748B] mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-4 space-y-3">
        <div className="flex flex-wrap gap-2">
          {RANGE_TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setRange(t.id)}
              className={`px-3 py-1.5 rounded-lg text-xs border ${
                range === t.id
                  ? "bg-[#3B82F6] text-white border-[#3B82F6]"
                  : "bg-white/[0.04] text-[#94A3B8] border-white/[0.06]"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          {STATUS_TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setStatus(t.id)}
              className={`px-3 py-1.5 rounded-lg text-xs border ${
                status === t.id
                  ? "bg-[#00E676]/20 text-[#00E676] border-[#00E676]/30"
                  : "bg-white/[0.04] text-[#94A3B8] border-white/[0.06]"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-8 h-8 border-2 border-[#00E676]/20 border-t-[#00E676] rounded-full animate-spin" />
        </div>
      ) : results.length === 0 ? (
        <div className="text-center py-16 rounded-2xl border border-white/[0.06] px-4">
          <Trophy className="w-12 h-12 mx-auto text-[#64748B] mb-3 opacity-50" />
          <p className="font-medium text-[#F8FAFC]">No evaluated results in this view</p>
          <p className="text-sm text-[#64748B] mt-2">
            Try a wider date range or check the archive for pending predictions awaiting final scores.
          </p>
          <Link to="/archive" className="text-[#00E676] text-sm mt-4 inline-block hover:underline">
            Open Prediction Archive
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {results.map((item, i) => (
            <ResultCard key={item.fixture_id} item={item} index={i} />
          ))}
        </div>
      )}
    </div>
  );
}
