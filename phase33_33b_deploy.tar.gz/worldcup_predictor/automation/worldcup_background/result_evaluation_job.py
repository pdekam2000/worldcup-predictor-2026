"""Evaluate finished World Cup fixtures against stored predictions — Phase 33."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from worldcup_predictor.api.prediction_history_evaluation import FixtureOutcomeResolver
from worldcup_predictor.automation.worldcup_background.pick_evaluator import evaluate_stored_prediction
from worldcup_predictor.automation.worldcup_background.prediction_store import WorldcupPredictionStore
from worldcup_predictor.config.settings import Settings, get_settings
from worldcup_predictor.database.repository import FootballIntelligenceRepository

logger = logging.getLogger(__name__)


@dataclass
class EvaluationJobResult:
    scanned: int = 0
    evaluated: int = 0
    pending: int = 0
    errors: int = 0
    details: list[dict[str, Any]] = field(default_factory=list)


def run_evaluate_worldcup_results(
    *,
    settings: Settings | None = None,
    competition_key: str = "world_cup_2026",
    limit: int = 100,
) -> EvaluationJobResult:
    settings = settings or get_settings()
    repo = FootballIntelligenceRepository(settings.sqlite_path or None)
    store = WorldcupPredictionStore(settings)
    resolver = FixtureOutcomeResolver(settings)

    finished = [
        dict(row)
        for row in repo.list_fixtures(competition_key=competition_key, status_class="finished", limit=limit)
    ]
    result = EvaluationJobResult(scanned=len(finished))

    for row in finished:
        fid = int(row["fixture_id"])
        stored = store.get(fid, locale="en")
        if stored is None:
            row_db = repo.get_worldcup_stored_prediction(fid)
            if row_db and row_db.get("payload_json"):
                import json

                try:
                    stored = json.loads(row_db["payload_json"])
                except json.JSONDecodeError:
                    stored = None
        if stored is None:
            result.pending += 1
            result.details.append({"fixture_id": fid, "status": "no_stored_prediction"})
            continue

        try:
            outcome = resolver.resolve(fid)
            evaluation = evaluate_stored_prediction(stored, outcome)
            repo.upsert_worldcup_prediction_evaluation(
                fixture_id=fid,
                evaluation=evaluation,
                outcome={
                    "actual_result": outcome.actual_result,
                    "final_score": outcome.final_score,
                    "is_finished": outcome.is_finished,
                },
            )
            if evaluation.get("status") == "pending":
                result.pending += 1
            else:
                result.evaluated += 1
            result.details.append({
                "fixture_id": fid,
                "status": evaluation.get("status"),
                "markets": evaluation.get("markets"),
            })
        except Exception as exc:
            logger.exception("Evaluation failed fixture %s", fid)
            result.errors += 1
            result.details.append({"fixture_id": fid, "status": "error", "reason": str(exc)})

    from worldcup_predictor.automation.worldcup_background.accuracy_summary import rebuild_accuracy_summary

    rebuild_accuracy_summary(settings=settings, competition_key=competition_key)
    return result
