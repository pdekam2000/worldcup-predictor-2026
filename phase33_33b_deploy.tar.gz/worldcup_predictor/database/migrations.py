"""Apply incremental schema migrations — idempotent, safe on existing databases."""

from __future__ import annotations

import sqlite3

from worldcup_predictor.database.schema import PHASE40_DDL, SCHEMA_VERSION

# Phase 39 tables/indexes (CREATE IF NOT EXISTS — never drops data)
PHASE39_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS fixture_enrichment (
        fixture_id INTEGER PRIMARY KEY,
        competition_key TEXT NOT NULL,
        league_id INTEGER,
        season INTEGER,
        events_json TEXT,
        lineups_json TEXT,
        statistics_json TEXT,
        players_json TEXT,
        odds_json TEXT,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (fixture_id) REFERENCES fixtures(fixture_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS league_import_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        competition_key TEXT NOT NULL,
        league_id INTEGER NOT NULL,
        season INTEGER NOT NULL,
        fixtures_imported INTEGER NOT NULL DEFAULT 0,
        fixtures_skipped INTEGER NOT NULL DEFAULT 0,
        enrichment_errors INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL,
        message TEXT,
        started_at TEXT NOT NULL,
        finished_at TEXT
    )
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_league_import_runs_comp_season
    ON league_import_runs(competition_key, season)
    """,
)

PHASE39_COLUMNS: tuple[tuple[str, str, str], ...] = (
    ("fixtures", "league_id", "INTEGER"),
    ("fixtures", "season", "INTEGER"),
    ("learning_records_v2", "learning_profile_key", "TEXT"),
)

PHASE41_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS sportmonks_fixture_enrichment (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fixture_id_api_football INTEGER,
        sportmonks_fixture_id INTEGER NOT NULL UNIQUE,
        league_id INTEGER NOT NULL,
        season_id INTEGER NOT NULL,
        endpoint TEXT NOT NULL,
        include_params TEXT NOT NULL,
        raw_json TEXT NOT NULL,
        fetched_at_utc TEXT NOT NULL,
        expires_at_utc TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'ok'
    )
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_sportmonks_fixture_enrichment_expires
    ON sportmonks_fixture_enrichment(expires_at_utc)
    """,
)

# Phase 28B — premium include access flags (non-destructive ALTER)
PHASE42B_SPORTMONKS_COLUMNS: tuple[tuple[str, str, str], ...] = (
    ("sportmonks_fixture_enrichment", "base_enrichment_available", "INTEGER NOT NULL DEFAULT 0"),
    ("sportmonks_fixture_enrichment", "premium_odds_available", "INTEGER NOT NULL DEFAULT 0"),
    ("sportmonks_fixture_enrichment", "premium_predictions_available", "INTEGER NOT NULL DEFAULT 0"),
    ("sportmonks_fixture_enrichment", "premium_xg_available", "INTEGER NOT NULL DEFAULT 0"),
    ("sportmonks_fixture_enrichment", "premium_odds_access_denied", "INTEGER NOT NULL DEFAULT 0"),
    ("sportmonks_fixture_enrichment", "premium_predictions_access_denied", "INTEGER NOT NULL DEFAULT 0"),
    ("sportmonks_fixture_enrichment", "premium_xg_access_denied", "INTEGER NOT NULL DEFAULT 0"),
)


# Phase 33 — background World Cup stored predictions + evaluations
PHASE44_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS worldcup_stored_predictions (
        fixture_id INTEGER PRIMARY KEY,
        competition_key TEXT NOT NULL DEFAULT 'world_cup_2026',
        kickoff_utc TEXT,
        payload_json TEXT NOT NULL,
        source TEXT NOT NULL DEFAULT 'background',
        predicted_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_wc_stored_pred_kickoff
    ON worldcup_stored_predictions(kickoff_utc)
    """,
    """
    CREATE TABLE IF NOT EXISTS worldcup_prediction_evaluations (
        fixture_id INTEGER PRIMARY KEY,
        competition_key TEXT NOT NULL DEFAULT 'world_cup_2026',
        overall_status TEXT NOT NULL DEFAULT 'pending',
        no_bet INTEGER NOT NULL DEFAULT 0,
        actual_result TEXT,
        final_score TEXT,
        safe_pick_status TEXT,
        value_pick_status TEXT,
        aggressive_pick_status TEXT,
        market_1x2_status TEXT,
        market_ou_status TEXT,
        market_btts_status TEXT,
        market_dc_status TEXT,
        detail_json TEXT,
        evaluated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS worldcup_accuracy_summary (
        competition_key TEXT PRIMARY KEY,
        summary_json TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
)

# Phase 32C — national team form/H2H history caches
PHASE43_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS fixture_team_resolution (
        fixture_id INTEGER PRIMARY KEY,
        home_team_id INTEGER,
        away_team_id INTEGER,
        resolution_source TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (fixture_id) REFERENCES fixtures(fixture_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS national_team_form_cache (
        team_id INTEGER PRIMARY KEY,
        team_name TEXT NOT NULL,
        matches_used INTEGER NOT NULL DEFAULT 0,
        last5_json TEXT,
        last10_json TEXT,
        home_json TEXT,
        away_json TEXT,
        neutral_json TEXT,
        recent_fixtures_json TEXT,
        national_form_score REAL,
        explanation_json TEXT,
        source TEXT NOT NULL DEFAULT 'cache_backfill',
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS national_team_h2h_cache (
        pair_key TEXT PRIMARY KEY,
        home_team_id INTEGER NOT NULL,
        away_team_id INTEGER NOT NULL,
        meetings_used INTEGER NOT NULL DEFAULT 0,
        meetings_json TEXT,
        national_h2h_score REAL,
        detail_json TEXT,
        source TEXT NOT NULL DEFAULT 'cache_backfill',
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_national_h2h_team_pair
    ON national_team_h2h_cache(home_team_id, away_team_id)
    """,
)


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?",
        (table,),
    ).fetchone()
    return row is not None


def _column_names(conn: sqlite3.Connection, table: str) -> set[str]:
    if not _table_exists(conn, table):
        return set()
    rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    return {str(row[1]) for row in rows}


def _add_column_if_missing(
    conn: sqlite3.Connection,
    table: str,
    column: str,
    typedef: str,
) -> bool:
    if column in _column_names(conn, table):
        return False
    conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {typedef}")
    return True


def ensure_schema_compat(conn: sqlite3.Connection) -> None:
    """Ensure Phase 39 columns/tables exist — always safe to call."""
    for ddl in PHASE39_DDL:
        conn.execute(ddl)

    for table, column, typedef in PHASE39_COLUMNS:
        if _table_exists(conn, table):
            _add_column_if_missing(conn, table, column, typedef)

    for ddl in PHASE40_DDL:
        conn.execute(ddl)

    for ddl in PHASE41_DDL:
        conn.execute(ddl)

    for table, column, typedef in PHASE42B_SPORTMONKS_COLUMNS:
        if _table_exists(conn, table):
            _add_column_if_missing(conn, table, column, typedef)

    for ddl in PHASE43_DDL:
        conn.execute(ddl)

    for ddl in PHASE44_DDL:
        conn.execute(ddl)

    conn.execute(
        "INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)",
        ("schema_version", str(SCHEMA_VERSION)),
    )
    conn.commit()


def apply_migrations(conn: sqlite3.Connection) -> None:
    """Legacy entry point — always runs idempotent schema compatibility checks."""
    ensure_schema_compat(conn)
